#include"Game.h"
 

int main() {

	Game* g=new Game;
	g->start();
	 
	delete g; 
	return 0;
}
